create
    definer = root@localhost function CountLayer(p_node_id int) returns int deterministic
BEGIN
declare p_result,p_lft,p_rgt int default 0;
if exists (select 1 from tree where node_id=p_node_id) then
begin
select lft, rgt into p_lft, p_rgt from tree where node_id=p_node_id;
select count(*) into p_result from tree where lft <= p_lft and rgt >= p_rgt;
end;
return p_result;
end if;
RETURN 0;
END;

