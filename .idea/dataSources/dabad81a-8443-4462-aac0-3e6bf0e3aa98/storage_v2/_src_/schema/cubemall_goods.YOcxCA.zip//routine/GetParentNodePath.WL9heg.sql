create
    definer = root@localhost procedure GetParentNodePath(IN p_node_id int)
BEGIN
declare p_lft,p_rgt int  default 0;  
if exists(select node_id from tree where node_id = p_node_id)  then 
    begin  
        select lft, rgt into p_lft, p_rgt from tree where node_id=p_node_id;
        select * from tree_view where lft < p_lft and rgt >p_rgt order by lft ASC ; 
    end ; 
end if;    
END;

