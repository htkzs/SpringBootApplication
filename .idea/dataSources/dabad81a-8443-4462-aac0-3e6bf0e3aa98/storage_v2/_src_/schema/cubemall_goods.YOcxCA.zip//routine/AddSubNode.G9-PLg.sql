create
    definer = root@localhost procedure AddSubNode(IN p_node_id int, IN p_node_name varchar(50))
BEGIN 
declare p_rgt  int  default 0; 
if exists(select node_id from tree where node_id = p_node_id)  then   
    begin  
		START TRANSACTION;
        select rgt into p_rgt  from tree where node_id =  p_node_id; 
        update tree set rgt = rgt + 2 where rgt >= p_rgt;  
        update tree set lft = lft + 2 where lft >= p_rgt;  
        insert into tree(name, lft, rgt) values(p_node_name, p_rgt, p_rgt + 1);
    COMMIT;
    end;  
end if;    
END;

