create
    definer = root@localhost procedure DelNode(IN p_node_id int)
BEGIN
declare p_lft,p_rgt int  default 0;  
if exists(select node_id from tree where node_id = p_node_id)  then 
START TRANSACTION;
  
            select lft, rgt into p_lft, p_rgt from tree where node_id=p_node_id; 
       
           delete from tree where lft>=p_lft and rgt<=p_rgt; 
update tree set lft=lft-(p_rgt - p_lft + 1) where lft > p_lft;
update tree set rgt=rgt-(p_rgt - p_lft + 1) where rgt > p_rgt; 

   COMMIT;
end if;
END;

