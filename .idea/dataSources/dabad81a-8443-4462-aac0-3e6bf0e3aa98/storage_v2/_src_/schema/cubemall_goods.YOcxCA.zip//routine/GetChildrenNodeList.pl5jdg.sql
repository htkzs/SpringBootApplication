create
    definer = root@localhost procedure GetChildrenNodeList(IN p_node_id int)
BEGIN 
declare p_lft,p_rgt int  default 0;  
if exists(select node_id from tree where node_id = p_node_id)  then 
    begin  
        select lft, rgt into p_lft, p_rgt from tree where node_id=p_node_id;
        select * from tree_view where lft between p_lft and p_rgt order by lft ASC ; 
    end; 
end if;    
END;

